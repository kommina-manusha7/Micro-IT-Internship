const board = document.getElementById("board");
const status = document.getElementById("status");
const resetBtn = document.getElementById("resetBtn");

let currentPlayer = "X";
let gameActive = true;
const cells = Array(9).fill(null);

function checkWinner() {
  const winPatterns = [
    [0,1,2], [3,4,5], [6,7,8],
    [0,3,6], [1,4,7], [2,5,8],
    [0,4,8], [2,4,6]
  ];

  for (let pattern of winPatterns) {
    const [a, b, c] = pattern;
    if (cells[a] && cells[a] === cells[b] && cells[a] === cells[c]) {
      return cells[a];
    }
  }

  if (!cells.includes(null)) {
    return "draw";
  }

  return null;
}

function handleClick(index, cellDiv) {
  if (!gameActive || cells[index]) return;

  cells[index] = currentPlayer;
  cellDiv.textContent = currentPlayer;
  cellDiv.classList.add(currentPlayer);

  const winner = checkWinner();

  if (winner === "draw") {
    status.textContent = "It's a draw!";
    gameActive = false;
  } else if (winner) {
    status.textContent = `Player ${winner} wins!`;
    gameActive = false;
  } else {
    currentPlayer = currentPlayer === "X" ? "O" : "X";
    status.textContent = `Player ${currentPlayer}'s turn`;
  }
}

function initBoard() {
  board.innerHTML = "";
  for (let i = 0; i < 9; i++) {
    const cell = document.createElement("div");
    cell.classList.add("cell");
    cell.addEventListener("click", () => handleClick(i, cell));
    board.appendChild(cell);
  }
}

resetBtn.addEventListener("click", () => {
  for (let i = 0; i < 9; i++) cells[i] = null;
  currentPlayer = "X";
  gameActive = true;
  status.textContent = "Player X's turn";
  initBoard();
});

initBoard();
